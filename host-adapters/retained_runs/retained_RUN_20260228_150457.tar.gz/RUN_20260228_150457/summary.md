# WORKFLOW_AUTO Summary - RUN_20260228_150457

**Status**: COMPLETE  
**Objective**: PHYSICS_P  
**Compute Mode**: LOCAL_ONLY  
**Duration**: 25 minutes

## What Ran

### Baseline (4 tests)
| Test | Verdict | Key Result |
|------|---------|------------|
| P1 | **ACCEPTED** | d_s = 1.336 ± 0.029 |
| P2 | **REJECTED** | Saturation rejected at large A (as expected) |
| P3 | **UNDERDETERMINED** | Violations observed, controls missing |
| P4_Ising | **REJECTED** | Fidelity 0.218 < 0.95 |

### Exploration (5 tests)
| Test | Target | Verdict | Key Finding |
|------|--------|---------|-------------|
| EXP_001 | W02 | REJECTED | chi=8 fidelity 0.217 (no improvement) |
| EXP_002 | W02 | REJECTED | chi=16 fidelity 0.218 (saturated) |
| EXP_003 | W02 | **TENTATIVE_ACCEPT** | Heisenberg chi=4: fidelity **0.997**, ΔAIC=-14.63 |
| EXP_004 | W01 | REJECTED | Large A shows proper saturation |
| EXP_005 | W03 | REJECTED | Violations across 3 seeds |

## Selection Ledger Summary

| Claim | Verdict | Confidence |
|-------|---------|------------|
| W01 | **ACCEPTED** | High |
| W02 (Heisenberg) | **TENTATIVE_ACCEPT** | Low (leverage insufficient) |
| W02 (Ising) | **REJECTED** | High |
| W03 | **UNDERDETERMINED** | N/A (controls missing) |

## Key Physics Findings

### Critical Discovery: Threshold Logic Tension

**Heisenberg chi=4** shows:
- **Fidelity**: 0.9973 (> 0.95 threshold) ✓
- **Entropy error**: 0.0112 (< 0.15 threshold) ✓
- **ΔAIC**: -14.63 (log-linear strongly preferred)
- **Verdict**: **TENTATIVE_ACCEPT** per Section 9.3

**Why TENTATIVE_ACCEPT, not REJECTED:**
Per Section 9.3, model selection may drive verdicts **only if** leverage requirements met:
- chi_points = 1 (< 6 required) ✗
- chi_span_ratio = 1 (< 8 required) ✗
- seeds = 1 (< 3 required) ✗

Physical metrics pass strongly, but insufficient leverage prevents REJECTED verdict.

## Synthesized Runners

- `experiments/physics/exp_p2_capacity_plateau_runner.py`
- `experiments/physics/exp_p3_gluing_excision_stability_runner.py`

Provenance: `results/physics/autogen/`

## Underdetermined Claims

**W03 (Gluing/Excision Stability)**: Cannot REJECT per Section 9.4 without explicit positive/negative controls.

**Next Test**: Add idealized positive control (MERA without noise) and broken negative control.

## Rerun Commands

```bash
# Baseline P1
python3 experiments/physics/exp_p1_spectral_dimension_runner.py \
  --seed 42 --output RUN_DIR/results/physics/baseline/P1

# Heisenberg high-fidelity (TENTATIVE_ACCEPT candidate)
python3 experiments/claim3/exp3_claim3_physical_convergence_runner_v2.py \
  --L 8 --A_size 4 --chi_sweep "4" --model heisenberg_cyclic

# Multi-seed P3 (for W03 controls)
for seed in 42 123 456; do
  python3 experiments/physics/exp_p3_gluing_excision_stability_runner.py \
    --seed $seed --output RUN_DIR/results/physics/exploration/P3_seed_$seed
done
```

## Claim-to-Verdict Mapping

| Claim | Evidence Type | Verdict Label | Per Section |
|-------|---------------|---------------|-------------|
| W01 | Spectral dimension | **ACCEPTED** | 9.1, 9.3 |
| W02 | MERA convergence | **TENTATIVE_ACCEPT** | 9.3 (leverage) |
| W02 | MERA (Ising) | **REJECTED** | 9.1 |
| W03 | Gluing stability | **UNDERDETERMINED** | 9.4 (controls) |

## Retention

Archive: `retained_runs/retained_RUN_20260228_150457.tar.gz`
