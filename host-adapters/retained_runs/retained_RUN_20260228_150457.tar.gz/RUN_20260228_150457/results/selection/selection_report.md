# Selection Report - RUN_20260228_150457

## Summary

| Claim | Verdict | Key Evidence | Confidence |
|-------|---------|--------------|------------|
| W01 | **ACCEPTED** | P1: d_s=1.336 (±0.029 vs 0.15 tolerance) | High |
| W02 | **TENTATIVE_ACCEPT** | Heisenberg fidelity=0.997, but insufficient leverage | Low |
| W02_Ising | **REJECTED** | Ising fidelity saturates at 0.22 < 0.95 | High |
| W03 | **UNDERDETERMINED** | Violations observed but controls missing | N/A |

## Key Findings

### W01: Spectral Dimension
- P1 spectral dimension test passed with d_s = 1.336
- Within tolerance of expected 1.365 (Sierpinski dimension)
- Verdict: ACCEPTED per Section 9.1

### W02: MERA Physical Convergence (Model-Dependent)

**Ising Model**: REJECTED
- Chi sweep 2→16 shows fidelity saturation at ~0.22
- Far below 0.95 threshold
- Model selection prefers log-linear (negative ΔAIC)
- Verdict: REJECTED per Section 9.1

**Heisenberg Model**: TENTATIVE_ACCEPT  
- Chi=4 achieves fidelity=0.997 (>0.95) ✓
- Entropy error 0.011 (<0.15) ✓
- ΔAIC=-14.63 (log-linear preferred by AIC)
- **Leverage check FAILS per Section 9.3:**
  - chi_points = 1 (< 6 required)
  - chi_span_ratio = 1 (< 8 required)  
  - seeds = 1 (< 3 required)
- Cannot use model selection to drive verdict
- Physical metrics pass strongly → TENTATIVE_ACCEPT

### W03: Gluing/Excision Stability
- Systematic violations across seeds 42, 123, 456
- **Blocked from REJECTED per Section 9.4:**
  - No positive control (idealized case where stability should hold)
  - No negative control (explicitly broken case)
- Verdict: UNDERDETERMINED
- Next test: Add controls per Section 9.4

## Threshold Refinement Recommendation

Section 9.2 interpretation validated:
|ΔAIC| = 14.63 indicates "very strong preference" for log-linear
But physical metrics (fidelity, entropy error) strongly favor saturation

At small systems (L=8), finite-size effects dominate statistical tests.
TENTATIVE_ACCEPT is appropriate when physical convergence is excellent but statistical leverage insufficient.

## Evidence Witness Validation

All witness paths verified:
- [x] results/science/baseline/P1/verdict.json exists
- [x] results/science/campaign/EXP_003/*/verdict.json exists
- [x] results/science/baseline/P4/*/verdict.json exists
- [x] results/science/baseline/P3/verdict.json exists

## Next Steps

1. **W02 Heisenberg**: Extend chi sweep to 2,4,8,16,32 with 3+ seeds
2. **W03**: Implement positive/negative controls for gluing tests
3. **Selection**: Re-run with expanded sweep for W02 resolution

## Compliance

WORKFLOW_AUTO.md Sections applied:
- 9.1: Verdict labels (ACCEPTED/TENTATIVE_ACCEPT/REJECTED/UNDERDETERMINED)
- 9.2: AIC/BIC interpretation (|ΔAIC| > 10 = very strong)
- 9.3: Leverage requirements (prevents REJECTED from low stats)
- 9.4: Controls requirement (blocks REJECTED without controls)
- 9.5: Fidelity sanity check (verified against raw outputs)

Report generated: 2026-02-28T20:25:00Z
