# P2: Capacity Plateau Scan Specification

## Purpose
Test whether entropy shows capacity-limited plateau behavior (saturating model) vs unbounded log-linear growth.

## Scientific Basis
Capacity-governed systems should show S(χ) → S_inf as χ increases, following saturating model:
S(χ) = S_inf - c * χ^(-α)

Alternative: log-linear model S(χ) = a + b*log(χ)

## Method
1. Simulate entropy measurements for χ sweep [2, 4, 8, 16, 32]
2. Fit both saturating and log-linear models
3. Compute AIC/BIC for model comparison

## Parameters
- chi_sweep: list[int] (default [2,4,8,16,32])
- L: int (default 16)
- A_size: int (default 8)
- seed: int (default 42)

## Acceptance Criteria
- P2.1: ΔAIC < 0 (saturating model preferred)
- P2.2: Monotonic entropy with increasing χ

## Outputs
- metadata.json: run configuration
- raw.csv: χ, S, S_true values
- fits.json: log-linear and saturating fits with AIC/BIC
- verdict.json: ACCEPT/REJECT with criteria breakdown
