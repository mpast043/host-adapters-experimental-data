# P3: Gluing/Excision Stability Specification

## Purpose
Test structural stability of entropy under gluing (combining subsystems) and excision (removing subsystems) operations.

## Scientific Basis
Capacity-governed systems should satisfy:
- Gluing: S(A|B) ≈ S(A) + S(B) (additivity)
- Excision: S after removal > 0 and well-defined

## Method
1. Generate MERA-like states for subsystems A, B
2. Compute gluing operation S_glued
3. Compute excision operation S_excised
4. Test additivity and positivity constraints

## Parameters
- chi_sweep: list[int] (default [2,4,8])
- threshold: float (default 0.5)
- seed: int (default 42)

## Acceptance Criteria
- P3.1_gluing_stable: |S_glued - (S_A + S_B)| < threshold for all χ
- P3.2_excision_valid: S_excised > 0 for all χ

## Outputs
- metadata.json: run configuration
- raw.csv: chi, entropies, violations
- verdict.json: ACCEPT/REJECT with criteria breakdown
