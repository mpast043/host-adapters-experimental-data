# P1: Spectral Dimension Test Specification

## Purpose
Estimate spectral dimension from random walk return probabilities as a proxy for system dimensionality.

## Scientific Basis
For a system with spectral dimension d_s, return probability scales as P(t) ~ t^(-d_s/2).

## Method
1. Generate simulated return probabilities for n_steps = [10, 20, 40, 80, 160, 320, 640, 1280]
2. Fit log(P) vs log(t) to extract slope
3. Compute d_s = -2 * slope

## Parameters
- seed: int (default 42)
- true_d_s: 1.35 (simulation ground truth)
- noise_level: 0.05

## Acceptance Criteria
- P1.1_spectral_dim: |d_s_estimated - true_d_s| < 0.15

## Outputs
- metadata.json: run_id, timestamp, config, version
- raw.json: measurements per step
- verdict.json: ACCEPT/REJECT with criteria breakdown
