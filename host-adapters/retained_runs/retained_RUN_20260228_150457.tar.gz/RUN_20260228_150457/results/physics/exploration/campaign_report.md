{
  "campaign_id": "RUN_20260228_150457",
  "phase": "EXPLORATION",
  "tests_completed": 5,
  "tests": [
    {"id": "EXP_001", "target": "W02", "test": "P4_mera_chi8", "verdict": "REJECT", "fidelity": 0.217, "delta_aic": -25.91, "note": "No improvement over chi=4"},
    {"id": "EXP_002", "target": "W02", "test": "P4_mera_chi16", "verdict": "REJECT", "fidelity": 0.218, "delta_aic": -25.90, "note": "Chi scaling saturated at low fidelity"},
    {"id": "EXP_003", "target": "W02", "test": "P4_heisenberg_chi4", "verdict": "REJECT", "fidelity": 0.997, "s_error": 0.011, "delta_aic": -14.63, "note": "Excellent physics, rejected by ΔAIC threshold"},
    {"id": "EXP_004", "target": "W01", "test": "P2_plateau_large_A", "verdict": "REJECT", "note": "Baseline ACCEPT was anomaly"},
    {"id": "EXP_005", "target": "W03", "test": "P3_gluing_robustness", "verdict": "REJECT", "seeds": [42,123,456], "note": "Systematic falsification across seeds"}
  ],
  "key_findings": [
    "Heisenberg model achieves fidelity=0.997 at chi=4 vs Ising failing at all chi",
    "Chi scaling for Ising saturates at fidelity ~0.22 (ansatz limitation)",
    "Gluing stability violations are systematic, not noise artifacts",
    "Statistical threshold (ΔAIC>0) rejects physically convergent systems"
  ],
  "recommendation": "Adopt threshold refinement: |ΔAIC|<2.0 → TENTATIVE_ACCEPT for fidelity>0.999"
}
