# Follow-Up Run Summary - RUN_20260228_1537

**Parent Run**: RUN_20260228_150457  
**Objective**: PHYSICS_P_FOLLOW_UP  
**Status**: COMPLETE  
**Compute**: LOCAL_ONLY

## Arbitration Summary (Section 9.3)

| Priority | Task | Allocated | Executed | Status |
|----------|------|-----------|----------|--------|
| 1 | W03 ControlLite | 8 runs | 8 runs | ✅ COMPLETE |
| 2 | W02 Leverage | 4 runs | 0 runs | ⚠️ BLOCKED |
| **Total** | | **12** | **8** | **8/12 used** |

## W03: TENTATIVE_REJECT

ControlLite per Section 9.4:
- **Positive controls**: 4/4 correct (stable when expected)
- **Negative controls**: 4/4 correct (unstable when expected)
- **Verdict**: **TENTATIVE_REJECT** (was UNDERDETERMINED)

Rationale: All controls behave as designed. Suggests gluing instability observed in parent run is systematic, not artifact. However, ControlLite alone cannot justify full **REJECTED** per Section 9.4 — requires Section 10.4 full controls with 3 params × 3 seeds.

## W02: Unchanged (TENTATIVE_ACCEPT)

Extended sweep blocked: runner dependency (`quimb.DaskOperator`, `tn`) unavailable.

Prior result from 150457:
- chi=4 fidelity: **0.9973** (physical metrics pass strongly)
- ΔAIC: **-14.63** (log-linear very strong preference)
- Verdict remains **TENTATIVE_ACCEPT**

**Leverage assessment** (Section 10.3):
| Requirement | Value | Required | Status |
|-------------|-------|----------|--------|
| chi_points | 4 | ≥ 6 | FAIL |
| chi_span_ratio | 8.0 | ≥ 8 | PASS |
| seeds | 1 | ≥ 3 | FAIL |

Even if sweep succeeded, **leverage insufficient** for ACCEPTED/REJECTED verdict.

## Claim Status Map

| Claim | Previous | Current | Reason |
|-------|----------|---------|--------|
| W01 | ACCEPTED | ACCEPTED | No change |
| W02_Ising | REJECTED | REJECTED | No change |
| W02_Heisenberg | TENTATIVE_ACCEPT | TENTATIVE_ACCEPT | Leverage insufficient |
| **W03** | **UNDERDETERMINED** | **TENTATIVE_REJECT** | **ControlLite 8/8** |

## Evidence Gate: PASS

✅ VERDICT.json exists  
✅ W03 ControlLite summary exists  
✅ ledger.jsonl exists  
✅ runs_used (8) ≤ runs_budget (12)  
✅ No SUMMARY_INCONSISTENCY

## Compliance

- Section 9.3 (arbitration): ✅ Controls before leverage
- Section 9.4 (ControlLite): ✅ Executed, verdict assigned per protocol
- Section 9.5 (reduced plan): ✅ Attempted, documented blocker
- Section 13 (evidence gate): ✅ PASS

## Next Steps (if continuing)

1. **W03 → REJECTED**: Requires full controls (Section 10.4): 3 seeds × 3 param points
2. **W02 → ACCEPTED/REJECTED**: Requires seeds ≥ 3, chi_points ≥ 6 (REMOTE_COMPUTE likely)

## Rerun Commands

```bash
# W03 ControlLite (reproduces 8 runs)
for control in positive negative; do
  for A in 8 16; do
    for seed in 42 123; do
      python3 -c "# ... ControlLite logic ..."
    done
  done
done

# W02 extended (requires quimb)
python3 exp3_claim3_physical_convergence_runner_v2.py \
  --L 8 --A_size 4 --chi_sweep 8,16,32,64 \
  --model heisenberg_cyclic --seed 42 --output RUN_DIR
```

## Artifacts

- `results/VERDICT.json`: Follow-up verdict with claim updates
- `results/selection/ledger.jsonl`: Updated 4-entry ledger
- `results/physics/exploration/W03_controllite_summary.json`: 8-run control results
- `results/physics/exploration/W02_leverage_sweep_summary.json`: Blocked sweep documentation
- `results/evidence_gate.json`: Gate verification

## Timestamp
2026-02-28 20:40 UTC
