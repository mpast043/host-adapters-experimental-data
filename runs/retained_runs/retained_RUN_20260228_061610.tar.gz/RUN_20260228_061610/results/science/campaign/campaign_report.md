# Campaign Report

Generated: 2026-02-28T06:16:27.561319+00:00
Mode: COMPLETE

| Test | Verdict | AIC delta | BIC delta | Artifact |
|---|---|---:|---:|---|
| claim_w02_poset_infimum | PASS |  |  | `results/science/claim_w02_poset_infimum` |
| claim_w06_depth_vector_monotonicity | PASS |  |  | `results/science/claim_w06_depth_vector_monotonicity` |
| claim_w08_class_splitting_monotonicity | PASS |  |  | `results/science/claim_w08_class_splitting_monotonicity` |
| claim_w13_cobs_decomposition_compat | PASS |  |  | `results/science/claim_w13_cobs_decomposition_compat` |
| claim_w14_ejection_expands_core | PASS |  |  | `results/science/claim_w14_ejection_expands_core` |
| claim_w16_time_consistency_monotone | PASS |  |  | `results/science/claim_w16_time_consistency_monotone` |
| claim_w09_delta_t_well_defined | PASS |  |  | `results/science/claim_w09_delta_t_well_defined` |
| claim_w10_observer_non_influence | PASS |  |  | `results/science/claim_w10_observer_non_influence` |
| claim_w12_observer_triad_mapping | PASS |  |  | `results/science/claim_w12_observer_triad_mapping` |
| claim_w03_memory_excision_consistency | PASS |  |  | `results/science/claim_w03_memory_excision_consistency` |
| claim_w04_self_reference_consistency | FAIL |  |  | `results/science/claim_w04_self_reference_consistency` |
| claim_w07_cross_axis_isolation | PASS |  |  | `results/science/claim_w07_cross_axis_isolation` |
| claim2_seed_perturbation | PASS |  |  | `results/science/claim2_seed321` |
| claim3_optionb_regime_check | PASS |  |  | `results/science/claim3_explore` |

## Skipped Planned Tests
- w03_memory_excision_consistency
- w04_self_reference_consistency
- w07_cross_axis_isolation
